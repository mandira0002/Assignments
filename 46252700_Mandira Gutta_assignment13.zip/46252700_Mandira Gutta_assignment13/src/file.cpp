#include <file.h>

wordset::wordset()
{
		cout<<"default constructor";
			cout<<endl;
}
//Add string in vector
int wordset::addmember(string s)
	{
	vlist.push_back(s);
	}
void wordset::display()
	{
	cout<<" The string is: "<<endl;
	for(auto itr=vlist.begin(); itr!=vlist.end(); itr++)
	{
	cout<<*itr<<" ";
	}
	cout<<endl;
	}
int wordset::deletemember(string delete_word)
{
	auto itr=find( vlist.begin(), vlist.end() , delete_word);
	if(itr!=vlist.end())
	{
	int index = itr - vlist.begin();
	vlist.erase( vlist.begin() + index);
	cout<<"After delete word - String is : ";
	for(auto itr = vlist.begin(); itr!=vlist.end(); itr++)
	{
	cout<<*itr<<" ";
	}
	cout<<endl;
	}
	else
	{
		cout<<" ~Invalid Word~ "<<endl;
	}
}
void wordset::empty_vlist()
{
	cout<<"The size of the vector list is: ";
	cout<<vlist.size()<<endl;
	vlist.clear();
	cout<<"The size of the vector after deleting is: ";
	cout<<vlist.size()<<endl;
}
void wordset::frequency()
	{
	map<string,int> Mp;
	for(int i=0;i<vlist.size();i++)
	{
		if(Mp.find(vlist[i]) == Mp.end())
		{
		Mp.insert(make_pair(vlist[i],1));
		}
		else
		Mp[vlist[i]]++;
	}
	cout<<"The frequency of the words is:"<<endl;
	    for(auto& itr:Mp)
	    {
		cout<<itr.first<<' '<<itr.second<<'\n';	
	    }
	}
	wordset::~wordset()
	{
		cout<<"destructor called" <<endl;
	}
