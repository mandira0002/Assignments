#include <file.h>
int main(int argc, char **argv)
{
		wordset w;
		for(int i=1; i<argc; i++)
		{
		w.addmember(argv[i]);
		}
		w.display();
		w.frequency();
		string delete_word;
		cout<<"Enter the word to delete: ";
		cin>>delete_word;
	        w.deletemember(delete_word);
		w.frequency();
		w.empty_vlist();
		return 0;
}


