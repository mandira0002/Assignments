#ifndef _FILE_H
#define _FILE_H
#include<bits/stdc++.h>
#include<iostream>
#include<vector>
#include<string>
using namespace std;
class wordset
{
		public:
			wordset();
			int addmember(string );
			int deletemember(string);
			void display();
			void empty_vlist();
			void frequency();
			~wordset();
																		
		private:
			vector<string> vlist;
};

#endif
