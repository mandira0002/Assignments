#include<iostream>
using namespace std;

class Employee
{
	private:
		char name[20];
		int age;
		int yos;
		int salary;
	public:
		Employee();
		void display();
		void setData();
		void updateSalary();
		~Employee();
};
