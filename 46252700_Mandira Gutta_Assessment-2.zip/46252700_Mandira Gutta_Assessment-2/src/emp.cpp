#include"emp.h"

Employee::Employee()  //Constructor of Employee class
{
	
}

void Employee::setData()  //Setting the data 
{
	cout<<"Enter Employee name ,age, years of service and salary:\n";
	cin>>name>>age>>yos>>salary;
}
void Employee::display()  //Defining display function
{
	cout<<"Displaying Employee details :\n";
	cout<<"Name : " <<name<<" Age: "<<age<<" Years of service: "<<yos<<" Updated Salary: "<<salary<<endl;
}
void Employee::updateSalary() //Logic to Update salary with respect to certain conditions
{
	if(yos>5 && yos<=10)
		salary=salary+(salary*0.05);
	else if(yos>10 && yos<=25)
		salary=salary+(salary*0.1);
	else if(yos>25)
		salary=salary+(salary*0.25);
}
Employee::~Employee()  //Destructor of Employee class
{
	
}
