#include"emp.h"
int main()
{
	int n=0;
	cout<<"Enter the number of Employees"<<endl;
	cin>>n;
	//Dynamic memory allocation
	Employee *e=new Employee[n];
	//Logic to take input
	cout<<"Enter employee details for"<<n<<" employees\n";
	for(int i=0;i<n;i++)
	{
		e[i].setData();
	}
	for(int i=0;i<n;i++)
	{
		e[i].updateSalary();   //Updating the salary here
	}
	cout<<"Employee details are:\n";
	for(int i=0;i<n;i++)
	{
		e[i].display();       //Displaying after updating salary
	}
	delete []e;
	return 0;
}


