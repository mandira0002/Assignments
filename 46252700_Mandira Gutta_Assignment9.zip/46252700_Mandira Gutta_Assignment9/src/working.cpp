#include"working.h"
Working::Working()
{
	cout<<"working def const\n";
}
Working::Working(string n,int a,string org,string des):Person(n,a)
{
	cout<<"working par const\n";
	organization=org;
	designation=des;
}
void Working::setWorking()
{
	Person::setPerson();
	cout<<"enter organization and designation of worker:";
	cin>>organization>>designation;
}
void Working::display()
{
	Person::display();
	cout<<"working information is:"<<organization<<" "<<designation<<endl;
}
Working::~Working()
{
	cout<<"working dest\n";
}

