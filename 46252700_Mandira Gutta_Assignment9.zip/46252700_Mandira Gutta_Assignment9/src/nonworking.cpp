#include"nonworking.h"
Nonworking::Nonworking()
{
	cout<<"non_working def const\n";
}
Nonworking::Nonworking(string n,int a,string mon,int dt):Person(n,a)
{
	cout<<"non_working par const\n";
	month=mon;
	date=dt;
}
void Nonworking::setNonworking()
{
	Person::setPerson();
	cout<<"enter month and date since not workinig:";
	cin>>month>>date;
}
void Nonworking::display()
{
	Person::display();
	cout<<"non working information is:"<<month<<" "<<date<<endl;
}
Nonworking::~Nonworking()
{
	cout<<"non_working dest\n";
}

