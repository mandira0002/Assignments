#include"student.h"
Student::Student()
{
	cout<<"student def const\n";
}
Student::Student(string n,int a,string in,int c1):Person(n,a)
{
	cout<<"student par const\n";
	inst=in;
	clas=c1;
}
void Student::setStudent()
{
	Person::setPerson();
	cout<<"enter institute and class of student:";
	cin>>inst>>clas;
}
void Student::display()
{
	Person::display();
	cout<<"student details are:"<<inst<<" "<<clas<<endl;
}
Student::~Student()
{
	cout<<"student dest\n";
}
