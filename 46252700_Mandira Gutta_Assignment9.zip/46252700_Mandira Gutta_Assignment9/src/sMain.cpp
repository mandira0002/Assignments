#include"student.h"
#include"working.h"
#include"nonworking.h"
int main()
{
	//Giving Student information to display
	Student st("Himanshi",21,"SRM",21);
	st.display();

	//Giving Working person information to display
	Working ww("Stephanie",22,"BOA","Cybersecurity");
	ww.display();

	//Giving Non-Working information to display
	Nonworking nw("Sabhyata",25,"october",2020);
	nw.display();
	Person *bp=new Student("Himanshi",21,"SRM",21);
	cout<<"\n invoke object display() using base pointer";
	cout<<"\n------";
	bp->display();
	return 0;
}
