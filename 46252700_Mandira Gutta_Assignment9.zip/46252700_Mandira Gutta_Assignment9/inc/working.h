#include"person.h"
class Working:public Person
{
	private:
		string organization;
		string designation;
	public:
		Working();
		Working(string,int,string,string);
		void setWorking();
		void display();
		~Working();
};
