#include"person.h"
class Nonworking:public Person
{
        private:
                string month;
                int date;
        public:
                Nonworking();
                Nonworking(string,int,string,int);
                void setNonworking();
                void display();
                ~Nonworking();
};
