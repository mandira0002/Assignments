#include"person.h"
class Student:public Person
{
	private:
		string inst;
		int clas;

	public:
		Student();
		Student(string,int,string,int);
		void setStudent();
		void display();
		~Student();
};
		
