#include<stl.h>

myStl::myStl()
{
}

void myStl::insertElement(string s)
{
		list1.push_back(s);
}

void myStl::display()
{
		for(list<string>::iterator it=list1.begin();it!=list1.end();it++)
				{
					cout<<*it<<endl;
				}
			cout<<endl;
}

void myStl::insertStack()
{
		for(auto it=list1.begin();it!=list1.end();it++)
				{
					stack1.push(*it);
				}
			cout<<"The elements in the stack are:"<<endl;
				while(!stack1.empty())
				{
					cout<<stack1.top()<<endl;
					stack1.pop();
				}
					cout<<endl;
						
}

myStl::~myStl()
{
}

