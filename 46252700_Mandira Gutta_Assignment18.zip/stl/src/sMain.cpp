#include<stl.h>
int main(int argc,char **argv)
{
		myStl s;
			
			cout<<"\nList:"<<endl;
			cout<<" "<<endl;
			for(int i=1;i<argc;i++)
			{
			s.insertElement(argv[i]);
			}
						
			s.display();
			cout<<"\nStack:"<<endl;
			cout<<" "<<endl;
									
			s.insertStack();
			return 0;
}

