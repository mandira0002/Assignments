#include<iostream>
#include<iterator>
#include<list>
#include<map>
#include<stack>
#include<cstring>
#ifndef _MYSTL_H
#define _MYSTL_H
using namespace std;
class myStl
{
		public:
					
			myStl();
							
			void insertElement(string);
			void display();
			void insertStack();
													
			~myStl();
		private:
															
			list<string> list1;
			stack<string> stack1;
};
#endif

