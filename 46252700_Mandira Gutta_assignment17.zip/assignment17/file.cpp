#include <iostream>
#include<string.h>
using namespace std;
void longestword(char *[]);
void replaceWord(char *[]);
int main()
{
		char *p[5];
		char line[50];
		int i=0;
		cout<<"Enter a line of 5 words"<<endl;
		cin.getline(line,50);
		p[i]=strtok(line," ");
		while(p[i]!=NULL)
		{
		i++;
		p[i]=strtok(NULL," ");
		}
		for(i=0;i<5;i++)
		cout<<p[i]<<endl;
		longestword(p);
		replaceWord(p);										
}	
void longestword(char *p[])
{
		char word[100];
		int length =0;
		int longlength=0;
		int endIndex=0;
		int i,j;
		strcpy(word,p[0]);
		longlength = strlen(p[0]);
		for(i=1; i<5 ;i++)
		{
		length = strlen(p[i]);
		if(length > longlength)
		{
		longlength = length;
		strcpy(word,p[i]);
		}
		else
			continue;
		}
		cout<<"longest word is "<<word<<endl;
}
void replaceWord(char *p1[])
{
		int i=0;
		int j=0;
		int flag=0;
		int start=0;
		char word[50];
		char nword[50];
		char output[50];
		string p[5];
		for(int i=0;i<5;i++)
	       {	
		string str=p1[i];
		strcpy(str,p[i]);
	}
		p[strlen(p) -1]='\0';
		word[strlen(word)-1]='\0';
		nword[strlen(nword)-1]='\0';
		cout<<"Enter the word to replaced"<<endl;
		cin.getline(word,50);
		cout<<"Enter the new word"<<endl;
		cin.getline(nword,50);
		cout<<p<<endl;
		cout<<word<<endl;
		cout<<nword<<endl;
		while(p[i] !='\0')
	{	
	if(p[i] == word[j])
	       {
	if(!flag)
		start=i;
	j++;
	if(word[j]== '\0')
	break;
	flag=1;
	       }
	else
	flag=start=j=0;
	i++;
	}
	{
		for(i=0;i<start;i++)
			output[i]=p[i];
		for(j=0;j<strlen(nword);j++)
				{
				output[i]=nword[j];
				i++;
		for(j=0;j<strlen(nword);j<strlen(p);j++)
				{
				output[i]=p[i];
				i++;
				}
				output[i]='\0' ;
				{
				cout<<"new line is "<<output<<endl;
				}
				else
				{
				cout<<"no such word found "<<endl;
				}
		
				}
	}

}
