#include<iostream>
#include "date.h"
using namespace std;

Date::Date()
{
	day=1;
	month=1;
	year=2002;
	cout<<"\tDefault connstructor called" << endl;
};

Date::Date(int d)
{
	day=d;
	cout<<"\tParameterised constructor 1 called" << endl;
};

Date::Date(int d, int m, int y)
{
	day=d;
	month=m;
	year=y;
	cout<<"\tParameterised constructor 2 called" << endl;
}

int Date::getYear()
{
	return year;
}

void Date::setDate(int day, int month, int year)
{
	cout << day << ":" << month << ":" << year << endl;
	this->day=day;
	this->month=month;
	this->year=year;
}
void Date::getDate()
{
	cout << day << "/" << month << "/" << year << endl;
}

string Date::getMonthName()
{
	cout<<"Enter a number from 1-12 ";
	cin>>month;
	{
		if(month==1)
			return "January";
		else if(month==2)
			return "February";
		else if(month==3)
			return "March";
		else if(month==4)
			return "April";
		else if(month==5)
			return "May";
		else if(month==6)
			return "June";
		else if(month==7)
			return "July";
		else if(month==8)
			return "August";
		else if(month==9)
			return "September";
		else if(month==10)
			return "October";
		else if(month==11)
			return "November";
		else if(month==12)
			return "December";
		else if(month>12)
			cout<< "Sorry I need a number from 1-12 "<<endl;
		else if(month<=12)
			cout<< "The month is "<<month<<endl;
	}
}
bool Date::checkLeapYear()
{
	cout<<"Enter a year:  ";
	cin>>year;
	if((year % 4==0 && year % 100 !=0) || year % 400==0)
	{
		return true;
	}
	else
	{
		return false;
	}
};
