#include "emp.h"
#include<cstring>
Employee::Employee(int id, char name[], char dob[])
{
	empId=id;
	strcpy(empName ,name);
	strcpy(empDOB, dob);
}
void Employee::update(int sal, int supid)
{
	empSal=sal;
	supId=supid;
}
void Employee::display()
{
	cout<<"\n employee id: "<<empId<<endl;
	cout<<"\n employee name: "<<empName<<endl;
	cout<<"\n employee DOB: "<<empDOB<<endl;
	cout<<"\n employee salary: "<<empSal<<endl;
	cout<<"\n supervisor id: "<<supId<<endl;
}
int Employee::getSupervisorReports()
{
	cout<<"\nenter supervisor id 1 or 2: "<<endl;
}

