#include "emp.h"

int main()
{
	cout<<"Main"<<endl;
	Employee e(2,"Mandira","23/08/2000");
	Employee e1(3, "Suhas","04/02/2000");
	e.update(500000,1);
	e1.update(600000,2);
	e.display();
	e1.display();
	e.getSupervisorReports();
	int i;
	cin>>i;
	if(i==1)
	{
		cout<<"\n ...supervisor id 1 under these employee details.... "<<endl;
		e.display();
	}
	else
	{
		cout<<"\n ...supervisor id 2 under these employee details...."<<endl;
		e1.display();
	}
	return 0;
}


