#ifndef _EMP_H
#define _EMP_H
#include<iostream>
using namespace std;

class Employee
{
	private:
		int empId;
		char empName[100];
		char empDOB[100];
		int empSal;
		int supId;

	public:
		Employee(int , char[], char[]);
		void update(int,int);
		void display();
		int getSupervisorReports();
};
#endif
