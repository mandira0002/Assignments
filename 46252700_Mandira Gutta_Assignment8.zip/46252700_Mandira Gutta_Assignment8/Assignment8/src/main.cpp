#include"str.h"
int main()
{
		myString s1;
		char line[100];
		cout<<"Enter a line:";
		cin.getline(line,100);
		char *str[5];
		int i=0;
		str[i]=strtok(line," ");
		while(str[i]!=NULL)
		{
		i++;
		str[i]=strtok(NULL," ");
		}
		int size=i;
		if(size<=5)
		{
		cout<<"The sentence is:";	
		for(int i=0;i<size;i++)
		{
			cout<<str[i]<<' ';
		}
		cout<<endl;
		}
		s1.longestword(str,size);
		char replace[20];
		char word[20];
		cout<<"Enter the word to be replace:";
		cin>>replace;
		cout<<"Enter the word to replace:";
		cin>>word;
		s1.replaceWord(str,size,replace,word);
		return 0;
}

