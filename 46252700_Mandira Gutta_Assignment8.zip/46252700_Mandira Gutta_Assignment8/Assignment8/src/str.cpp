#include"str.h"
myString::myString()
{
		str=NULL;
			size=0;
}
myString::myString(char *s)
{
		size=(strlen(s))+1;
			str=(char*)new char(size);
				strcpy(str,s);
}
void myString::setString(char *s)
{
		size=(strlen(s))+1;
			str=(char*)new char(size);
				strcpy(str,s);
}
void myString::getString() 
{
		cout<<"My string is:"<<str<<endl;
}
void myString::longestword(char *str[],int size)
{
		int max=0;
		int k;
		int length[size];
		for(int i=0;i<size;i++)
		{
		int len=strlen(str[i]);
		length[i]=len;
		}
		for(int i=0;i<size;i++)
		{
		if(length[i]>max)
		{
		max=length[i];
		k=i;												
		}
		cout<<"The longest word in the sentence is:"<<str[k]<<endl;
		}
		void myString::replaceWord(char *str[],int size,char replace[],char word[])
		{
		int len1=strlen(word);
		char s1[len1];
		for(int i=0;i<size;i++)
		{
			int j;
			string s=str[i];
			if((s.compare(replace))==0)
		{															j=i;
			strcpy(s1,word);
			str[j]=s1;
		}
		break;

		}
		cout<<"The sentence after replace:"<<endl;
		for(int i=0;i<size;i++)
		{
		cout<<str[i]<<' ';
		}	
		cout<<endl;
		}
		myString :: ~myString()
		{
		}
}




