#include<iostream>
#include<stdio.h>
#include<string.h>
#include<memory>
#include<cstring>
#include<new>
using namespace std;
class myString
{
		private:
			char *str;
			int size;
								
		public:
			myString();
			myString(char *s);
			void setString(char*);
			void getString();
			void longestword(char *str[],int size);
			void replaceWord(char *str[],int size,char *replace,char *word);
			~myString();
};


