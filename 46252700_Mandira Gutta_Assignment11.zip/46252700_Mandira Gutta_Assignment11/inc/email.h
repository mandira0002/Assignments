#ifndef _EMAIL_H
#define _EMP_H

#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;

class Email
{
	private:
		string u_name;
		string host;
		string d_name;
	public:
		Email();
		Email(string,string,string);
		void display();
		~Email();
};
#endif
