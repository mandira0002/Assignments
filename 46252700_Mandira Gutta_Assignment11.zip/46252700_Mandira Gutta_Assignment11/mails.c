mandira0002@gmail.com
mg6945@srmist.edu.in
mandira.gutta@capgemini.com

