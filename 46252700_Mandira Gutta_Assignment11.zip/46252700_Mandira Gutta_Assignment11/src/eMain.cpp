#include"email.h"
int main(int argc, char *argv[])
{
	Email e1;
	string mail;
	fstream fobj;
	int count=0;
	fobj.open(argv[1],ios::in);
	if(!fobj)
	{
		cout<<"no such file\n";
	}
	else
	{
		if(fobj.is_open())
		{
			while(getline(fobj,mail))
			{
				cout<<mail<<endl;
			}
		}
	}
	fobj.close();
	fobj.open(argv[1],ios::in);
	{
		if (fobj.is_open())
		{
			while(getline(fobj,mail))
			{
				if((mail.find('@') !=std::string::npos)&&(mail.find(".com")!=std::string::npos) || (mail.find(".edu")!=std::string::npos))
				{
					count++;
					int len=mail.length();
					int i=(int)mail.find('@');
					string user =mail.substr(0,i);
					int j=(int)mail.find('.');
					string ehost=mail.substr(i+1,j-i-1);
					int k=(int)mail.find('.');
					string domain=mail.substr(k+1,len);
					cout<<"\n Mail username, host and domain are:";
					cout<<"\n.......\n";
					e1=Email(user,ehost,domain);
					e1.display();
				}
				else
				{
					cout<<"Invalid Email=>Must include @ and .com or .edu:\t"<<mail<<endl;
				}
			}
		}
		fobj.close();
	}
	fobj.open(argv[1],ios::in);
	if(fobj.is_open())
	{
		cout<<"the valid mail ids are:\n";
		cout<<".......\n";
		while(getline(fobj,mail))
		{
			if((mail.find('@')!=std::string::npos) && (mail.find(".com")!=std::string::npos) || (mail.find(".edu")!= std::string::npos))
			{
				cout<<mail<<endl;
			}
		}
	}
	fobj.close();
	
	return 0;
}
