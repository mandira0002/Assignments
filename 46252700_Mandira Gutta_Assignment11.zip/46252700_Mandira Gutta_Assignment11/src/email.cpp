#include"email.h"

Email::Email()
{
	cout<<"default";
}
Email::Email(string user, string ehost,string domain)
{
	u_name=user;
	host=ehost;
	d_name=domain;
}
void Email::display()
{
	cout<<"username:"<<u_name<<endl;
	cout<<"host:"<<host<<endl;
	cout<<"domain name:"<<d_name<<endl;
}
Email::~Email()
{
}

