#include<iostream>
#include<exception>
using namespace std;

int main(int argc, char*argv[])
{
	try
	{
		if(argc<3)
		{
			throw("Invalid arguments");
		}
		else
		{
			int n=argc-1;
			int index;
			string *obj=new string[n];
			for(int i=1,j=0;i<argc;i++,j++)
			{
				obj[j]=argv[i];
			}
			for(int i=0;i<n;i++)
				cout<<obj[i]<<endl;
			cout<<"enter the index:"<<endl;
			cin>>index;
			try
			{
				if(index<0)
				{
					throw("underflow\n");
				}
				else if(index>=n)
				{
					throw("overflow\n");
				}
				else
				{
					cout<<obj[index]<<endl;
				}
			}
			catch(const char *str)
			{
				cout<<"exeception:"<<str<<endl;
			}
		}
	}
	catch(const char *str)
	{
		cout<<"exception:"<<str<<endl;
	}
}

